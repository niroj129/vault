# Deploy the Game Points app on PythonAnywhere (free)

This puts your app online at `https://YOURNAME.pythonanywhere.com` so your team
can use it from anywhere. Free, no credit card, and your data (brands + points)
stays saved.

Your app already has the 3 brands set up (Tiffany, Stardust, Spincity) with
their Telegram groups — uploading `vault.db` brings all of that with it, so you
won't have to redo anything.

---

## 1. Create a free account
Go to https://www.pythonanywhere.com → **Pricing & signup** → **Create a
Beginner account** (the free one). Pick a username — that becomes part of your
web address.

## 2. Upload the project
Easiest way:
1. On your Mac, the whole app is in the folder `vault-alert`. A ready-made zip
   is here: `vault-alert/vault-alert-deploy.zip`.
2. On PythonAnywhere, open the **Files** tab → **Upload a file** → choose that
   zip.
3. Open a **Bash console** (Consoles tab → Bash) and unzip it:
   ```bash
   unzip vault-alert-deploy.zip -d vault-alert
   ```
   You should now have `/home/YOURNAME/vault-alert/app.py` etc.

## 3. Install Flask
In the same Bash console:
```bash
pip3 install --user Flask
```

## 4. Create the web app
1. Go to the **Web** tab → **Add a new web app** → **Next**.
2. Choose **Manual configuration** (NOT "Flask") → pick **Python 3.10**
   (or whatever 3.x is offered) → **Next**.

## 5. Point it at your code
1. Still on the **Web** tab, find the **Code** section → click the **WSGI
   configuration file** link (named like
   `/var/www/YOURNAME_pythonanywhere_com_wsgi.py`).
2. **Delete everything** in that file.
3. Open `pythonanywhere_wsgi.py` from your project, copy all of it, and paste
   it in.
4. Change `YOURNAME` (in the `project_path` line) to your PythonAnywhere
   username. **Save** (top right).

## 6. Go live
Back on the **Web** tab, click the big green **Reload** button. Then visit:
```
https://YOURNAME.pythonanywhere.com
```
Log in as `tiffany` / `Pass123` (or stardust / spincity). Done — it's online.

---

## Day-to-day use
- Each brand logs in and manages its own games.
- Add a game, update points, or hit **🔔 Remind** with a custom load amount.
- When a game's combined points drop below **100**, the brand's Telegram group
  gets an automatic alert.

## Managing logins on the server
Open a Bash console on PythonAnywhere:
```bash
cd ~/vault-alert
python3 manage.py list                          # see all brands
python3 manage.py add <user> <password> <Brand> # add a new brand login
python3 manage.py set-pw <user> <newpassword>   # change a password
python3 manage.py set-group <user> <chat_id>    # change a brand's Telegram chat
```
After adding/removing logins you do NOT need to reload the web app — changes are
live immediately.

## Important notes
- **Change the passwords** before sharing: `python3 manage.py set-pw tiffany NewPass`.
- Telegram's `api.telegram.org` is allowed on PythonAnywhere free accounts, so
  alerts work. (Free accounts route outbound traffic through a proxy; the app
  uses it automatically.)
- The free plan asks you to click a "Run until 3 months from now" button on the
  Web tab every ~3 months to keep the site up. PythonAnywhere emails you a
  reminder.

## Run locally on your Mac (for testing)
```bash
cd vault-alert
python3 app.py
# open http://localhost:8000
```
